If you have a general question about how to use this SDK or Facebook's Graph API, you should be posting a question at https://groups.google.com/group/pythonforfacebook instead of creating an issue here. Bugs in the Graph API should be reported at https://developers.facebook.com/bugs/.

PLEASE DELETE THE ABOVE AFTER READING IT AND FILL IN EACH OF THE FOLLOWING SECTIONS.

### Version of the SDK being used

### Expected Behavior

### Actual Behavior

### Steps to Reproduce
